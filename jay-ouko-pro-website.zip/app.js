/* =========================================================
   JAY OU​KO PRO APP
   - Supabase central database/auth
   - EmailJS optional admin notifications
   - WhatsApp quick notification fallback
   - Local FAQ "Jay AI" assistant
   ========================================================= */

const CONFIG = {
  // 1) Create a Supabase project and paste its URL + PUBLISHABLE key here.
  // Never put a Supabase service-role/secret key in this file.
  SUPABASE_URL: "PASTE_YOUR_SUPABASE_URL_HERE",
  SUPABASE_PUBLISHABLE_KEY: "PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE",

  // 2) Optional EmailJS setup for automatic email notifications.
  EMAILJS_PUBLIC_KEY: "PASTE_YOUR_EMAILJS_PUBLIC_KEY_HERE",
  EMAILJS_SERVICE_ID: "PASTE_YOUR_EMAILJS_SERVICE_ID_HERE",
  EMAILJS_TEMPLATE_ID: "PASTE_YOUR_EMAILJS_TEMPLATE_ID_HERE",

  ADMIN_EMAIL: "emmanuelouko21@gmail.com",
  WHATSAPP_NUMBER: "254142617814",
  MPESA_NUMBER: "0142617814"
};

const SQL_SETUP = `-- JAY OU​KO PRO / SUPABASE SETUP
-- Run this once in Supabase SQL Editor.
-- Then create an Auth user with the admin email ${CONFIG.ADMIN_EMAIL}.
-- The policies below let the public submit forms while only your admin
-- email can read/update the private admin queues.

create table if not exists public.registrations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null,
  email text not null,
  phone text not null,
  program text not null,
  preferred_contact text default 'WhatsApp',
  plan text default 'Free Class',
  message text default '',
  status text not null default 'pending' check (status in ('pending','approved','rejected'))
);

create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null,
  email text not null,
  phone text not null,
  service text not null,
  budget text not null,
  preferred_contact text default 'WhatsApp',
  message text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected'))
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null,
  role text default '',
  rating int not null default 5 check (rating between 1 and 5),
  comment text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected'))
);

alter table public.registrations enable row level security;
alter table public.leads enable row level security;
alter table public.reviews enable row level security;

-- Public insert policies
drop policy if exists "public can submit registrations" on public.registrations;
create policy "public can submit registrations"
on public.registrations for insert
to anon, authenticated
with check (true);

drop policy if exists "public can submit leads" on public.leads;
create policy "public can submit leads"
on public.leads for insert
to anon, authenticated
with check (true);

drop policy if exists "public can submit reviews" on public.reviews;
create policy "public can submit reviews"
on public.reviews for insert
to anon, authenticated
with check (true);

-- Public can only see approved reviews
drop policy if exists "public can read approved reviews" on public.reviews;
create policy "public can read approved reviews"
on public.reviews for select
to anon, authenticated
using (status = 'approved');

-- Admin policies: replace the email below if you use another admin email
drop policy if exists "admin can read registrations" on public.registrations;
create policy "admin can read registrations"
on public.registrations for select
to authenticated
using ((auth.jwt() ->> 'email') = '${CONFIG.ADMIN_EMAIL}');

drop policy if exists "admin can update registrations" on public.registrations;
create policy "admin can update registrations"
on public.registrations for update
to authenticated
using ((auth.jwt() ->> 'email') = '${CONFIG.ADMIN_EMAIL}')
with check ((auth.jwt() ->> 'email') = '${CONFIG.ADMIN_EMAIL}');

drop policy if exists "admin can read leads" on public.leads;
create policy "admin can read leads"
on public.leads for select
to authenticated
using ((auth.jwt() ->> 'email') = '${CONFIG.ADMIN_EMAIL}');

drop policy if exists "admin can update leads" on public.leads;
create policy "admin can update leads"
on public.leads for update
to authenticated
using ((auth.jwt() ->> 'email') = '${CONFIG.ADMIN_EMAIL}')
with check ((auth.jwt() ->> 'email') = '${CONFIG.ADMIN_EMAIL}');

drop policy if exists "admin can read reviews" on public.reviews;
create policy "admin can read reviews"
on public.reviews for select
to authenticated
using ((auth.jwt() ->> 'email') = '${CONFIG.ADMIN_EMAIL}');

drop policy if exists "admin can update reviews" on public.reviews;
create policy "admin can update reviews"
on public.reviews for update
to authenticated
using ((auth.jwt() ->> 'email') = '${CONFIG.ADMIN_EMAIL}')
with check ((auth.jwt() ->> 'email') = '${CONFIG.ADMIN_EMAIL}');

-- Grant minimum browser privileges; RLS controls the rows.
grant insert on public.registrations to anon, authenticated;
grant insert on public.leads to anon, authenticated;
grant insert, select on public.reviews to anon, authenticated;
grant select, update on public.registrations to authenticated;
grant select, update on public.leads to authenticated;
grant select, update on public.reviews to authenticated;
`;

let supabase = null;
const isSupabaseConfigured =
  window.supabase &&
  CONFIG.SUPABASE_URL.startsWith("https://") &&
  !CONFIG.SUPABASE_URL.includes("PASTE_") &&
  CONFIG.SUPABASE_PUBLISHABLE_KEY &&
  !CONFIG.SUPABASE_PUBLISHABLE_KEY.includes("PASTE_");

if (isSupabaseConfigured) {
  supabase = window.supabase.createClient(
    CONFIG.SUPABASE_URL,
    CONFIG.SUPABASE_PUBLISHABLE_KEY,
    { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } }
  );
}

if (window.emailjs && CONFIG.EMAILJS_PUBLIC_KEY && !CONFIG.EMAILJS_PUBLIC_KEY.includes("PASTE_")) {
  emailjs.init({ publicKey: CONFIG.EMAILJS_PUBLIC_KEY });
}

const qs = (s, root = document) => root.querySelector(s);
const qsa = (s, root = document) => [...root.querySelectorAll(s)];
const toastEl = qs("#toast");

function toast(message) {
  toastEl.textContent = message;
  toastEl.classList.add("show");
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => toastEl.classList.remove("show"), 3000);
}

function showResult(el, message, type = "") {
  el.className = `form-result ${type}`;
  el.textContent = message;
}

function openModal(id) {
  const el = qs(`#${id}`);
  if (!el) return;
  el.classList.add("open");
  el.setAttribute("aria-hidden", "false");
  document.body.classList.add("modal-open");
}

function closeModal(id) {
  const el = qs(`#${id}`);
  if (!el) return;
  el.classList.remove("open");
  el.setAttribute("aria-hidden", "true");
  if (!qsa(".modal-backdrop.open").length) document.body.classList.remove("modal-open");
}

function safe(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[c]));
}

function makeId(prefix = "jo") {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function localGet(key, fallback = []) {
  try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); } catch { return fallback; }
}

function localSet(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

// ---------------- THEME ----------------
const savedTheme = localStorage.getItem("jayOukoTheme");
if (savedTheme === "light") document.documentElement.classList.add("light");

qs("#themeToggle")?.addEventListener("click", () => {
  const light = document.documentElement.classList.toggle("light");
  localStorage.setItem("jayOukoTheme", light ? "light" : "dark");
  qs("#themeToggle i").className = light ? "fa-solid fa-moon" : "fa-solid fa-sun";
});
if (document.documentElement.classList.contains("light")) qs("#themeToggle i").className = "fa-solid fa-moon";

// ---------------- NAVIGATION ----------------
const navToggle = qs("#navToggle");
const navMenu = qs("#navMenu");

function closeNav() {
  navMenu?.classList.remove("open");
  navToggle?.classList.remove("active");
  navToggle?.setAttribute("aria-expanded", "false");
  navToggle?.setAttribute("aria-label", "Open navigation");
  document.body.classList.remove("menu-open");
}

navToggle?.addEventListener("click", () => {
  const open = navMenu.classList.toggle("open");
  navToggle.classList.toggle("active", open);
  navToggle.setAttribute("aria-expanded", String(open));
  navToggle.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
  document.body.classList.toggle("menu-open", open);
});
qsa("#navMenu a").forEach(a => a.addEventListener("click", closeNav));

document.addEventListener("click", (event) => {
  if (window.innerWidth > 860) return;
  if (!navMenu?.classList.contains("open")) return;
  if (!navMenu.contains(event.target) && !navToggle.contains(event.target)) closeNav();
});

// ---------------- SCROLL / REVEALS ----------------
const progress = qs("#scrollProgress");
const header = qs(".site-header");

function onScroll() {
  const h = document.documentElement.scrollHeight - window.innerHeight;
  progress.style.width = `${h > 0 ? (window.scrollY / h) * 100 : 0}%`;
  header.classList.toggle("is-scrolled", window.scrollY > 10);
}
window.addEventListener("scroll", onScroll, { passive: true });
onScroll();

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: .08 });
qsa(".reveal").forEach(el => revealObserver.observe(el));

// ---------------- PORTFOLIO FILTER ----------------
qsa(".filter-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    qsa(".filter-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    const filter = btn.dataset.filter;
    qsa(".project-card").forEach(card => {
      const show = filter === "all" || card.dataset.category === filter;
      card.style.display = show ? "" : "none";
    });
  });
});

const projectDetails = {
  portfolio: {
    title: "Jay Classic Portfolio",
    body: "A premium personal portfolio designed to turn attention into enquiries with a clear story, services, work samples and direct contact paths.",
    points: ["Responsive layout for phone, tablet and desktop", "Strong hire flow with service and budget selection", "Modern visual system with anime-tech styling", "Direct WhatsApp, email and call actions"]
  },
  design: {
    title: "Creator Promo Kit",
    body: "A coordinated creative package for social media that keeps typography, layout and messaging consistent across posts and promotional assets.",
    points: ["Social-post ready concepts", "Reusable Canva-friendly visual direction", "Clear creator positioning", "Designed for fast content publishing"]
  },
  marketing: {
    title: "Social Growth Dashboard",
    body: "A simple visual framework for planning content, tracking campaign actions and identifying what to improve next.",
    points: ["Content planning structure", "Campaign idea tracking", "Audience-action focus", "Simple decision-making workflow"]
  },
  ai: {
    title: "AI Content Workflow",
    body: "A repeatable AI-assisted content system that moves from idea to draft to polish while keeping human review in the process.",
    points: ["Prompt library structure", "Draft and polish workflow", "Repurposing ideas", "Human review before publishing"]
  },
  brand: {
    title: "Personal Brand Starter",
    body: "A clean identity foundation for a digital professional who needs consistent visuals and messaging across platforms.",
    points: ["Brand direction", "Social profile positioning", "Content visual language", "Professional contact structure"]
  },
  flow: {
    title: "Hire & Registration Flow",
    body: "The website connects public visitors to forms, notifications, approval queues and protected admin access using Supabase.",
    points: ["Project lead intake", "Member registration", "Admin approval queue", "Central storage with Row Level Security"]
  }
};

qsa("[data-project]").forEach(btn => {
  btn.addEventListener("click", () => {
    const item = projectDetails[btn.dataset.project];
    if (!item) return;
    qs("#projectModalTitle").textContent = item.title;
    qs("#projectModalBody").textContent = item.body;
    qs("#projectModalPoints").innerHTML = item.points.map(p => `<div class="modal-point">${safe(p)}</div>`).join("");
    openModal("projectModal");
  });
});

qsa("[data-close-modal]").forEach(btn => btn.addEventListener("click", () => closeModal(btn.dataset.closeModal)));
qsa(".modal-backdrop").forEach(backdrop => {
  backdrop.addEventListener("click", (e) => {
    if (e.target === backdrop) closeModal(backdrop.id);
  });
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    qsa(".modal-backdrop.open").forEach(m => closeModal(m.id));
    qs("#chatPanel")?.classList.remove("open");
    qs("#chatPanel")?.setAttribute("aria-hidden", "true");
    closeNav();
  }
});

// ---------------- PRICING SHORTCUTS ----------------
qsa(".plan-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    const plan = btn.dataset.plan;
    const budget = qs('select[name="budget"]', qs("#hireForm"));
    if (budget) {
      const option = [...budget.options].find(o => o.textContent.includes(plan.split("—")[1]?.trim() || plan.split(" ")[0]));
      if (option) budget.value = option.value;
      if (plan.includes("500")) budget.value = "KSh 500+";
      if (plan.includes("1,500")) budget.value = "KSh 1,500";
      if (plan.includes("3,000")) budget.value = "KSh 3,000";
      if (plan.includes("5,000")) budget.value = "KSh 5,000";
      if (plan.includes("7,500")) budget.value = "KSh 7,500";
      if (plan.includes("10,000")) budget.value = "KSh 10,000";
    }
    qs("#hire")?.scrollIntoView({ behavior: "smooth", block: "start" });
    setTimeout(() => qs('#hireForm input[name="name"]')?.focus(), 500);
  });
});

qs("#copyMpesa")?.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(CONFIG.MPESA_NUMBER);
    toast("M-PESA number copied.");
  } catch { toast(`M-PESA: ${CONFIG.MPESA_NUMBER}`); }
});

// ---------------- DATA LAYER ----------------
async function insertRecord(table, data) {
  if (supabase) {
    const { data: inserted, error } = await supabase.from(table).insert(data).select().single();
    if (error) throw error;
    return inserted;
  }
  const key = table === "registrations" ? "joLocalRegistrations" : table === "leads" ? "joLocalLeads" : "joLocalReviews";
  const rows = localGet(key, []);
  const row = { id: makeId(table.slice(0, 3)), created_at: new Date().toISOString(), ...data };
  rows.unshift(row);
  localSet(key, rows);
  return row;
}

async function getPublicReviews() {
  if (supabase) {
    const { data, error } = await supabase.from("reviews").select("*").eq("status", "approved").order("created_at", { ascending: false });
    if (error) throw error;
    return data || [];
  }
  return localGet("joLocalReviews", []).filter(r => r.status === "approved");
}

async function getAdminTable(table) {
  if (!supabase) throw new Error("Supabase is not configured. Admin access requires Supabase.");
  const { data: authData } = await supabase.auth.getUser();
  const email = authData?.user?.email;
  if (!email || email.toLowerCase() !== CONFIG.ADMIN_EMAIL.toLowerCase()) throw new Error("Admin account required.");
  const { data, error } = await supabase.from(table).select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return data || [];
}

async function updateAdminRecord(table, id, status) {
  if (!supabase) throw new Error("Supabase is not configured.");
  const { error } = await supabase.from(table).update({ status }).eq("id", id);
  if (error) throw error;
}

// ---------------- EMAIL + WHATSAPP NOTIFY ----------------
async function sendAdminEmail(subject, payload) {
  const ready = window.emailjs &&
    CONFIG.EMAILJS_PUBLIC_KEY && !CONFIG.EMAILJS_PUBLIC_KEY.includes("PASTE_") &&
    CONFIG.EMAILJS_SERVICE_ID && !CONFIG.EMAILJS_SERVICE_ID.includes("PASTE_") &&
    CONFIG.EMAILJS_TEMPLATE_ID && !CONFIG.EMAILJS_TEMPLATE_ID.includes("PASTE_");
  if (!ready) return false;

  try {
    await emailjs.send(CONFIG.EMAILJS_SERVICE_ID, CONFIG.EMAILJS_TEMPLATE_ID, {
      to_email: CONFIG.ADMIN_EMAIL,
      subject,
      ...payload
    });
    return true;
  } catch (error) {
    console.warn("EmailJS notification failed:", error);
    return false;
  }
}

function whatsappNotify(title, data) {
  const msg = [
    `*JAY OU​KO WEBSITE — ${title}*`,
    `Name: ${data.name || "-"}`,
    `Email: ${data.email || "-"}`,
    `Phone: ${data.phone || "-"}`,
    data.service ? `Service: ${data.service}` : "",
    data.program ? `Programme: ${data.program}` : "",
    data.budget ? `Budget: ${data.budget}` : "",
    data.plan ? `Plan: ${data.plan}` : "",
    data.message ? `Message: ${data.message}` : "",
    "Status: PENDING — review required"
  ].filter(Boolean).join("\n");

  const url = `https://wa.me/${CONFIG.WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
  window.open(url, "_blank", "noopener");
}

function notifySubmission(title, data) {
  whatsappNotify(title, data);
  sendAdminEmail(title, data);
}

// ---------------- HIRE FORM ----------------
qs("#hireForm")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.currentTarget;
  const result = qs("#hireResult");
  showResult(result, "Submitting project request…");
  const data = Object.fromEntries(new FormData(form).entries());

  try {
    const row = await insertRecord("leads", data);
    showResult(result, "Request received. Your project is now in the review queue.", "success");
    form.reset();
    notifySubmission("NEW PROJECT REQUEST", { ...data, id: row.id });
    toast("Project request submitted.");
  } catch (error) {
    console.error(error);
    showResult(result, "Submission failed. Please use WhatsApp or email directly.", "error");
  }
});

// ---------------- REGISTRATION ----------------
qs("#registrationForm")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.currentTarget;
  const result = qs("#registrationResult");
  showResult(result, "Submitting registration…");
  const data = Object.fromEntries(new FormData(form).entries());

  try {
    const row = await insertRecord("registrations", data);
    showResult(result, "Registration received. Jay will review it and contact you.", "success");
    form.reset();
    notifySubmission("NEW MEMBER REGISTRATION", { ...data, id: row.id });
    toast("Registration submitted.");
  } catch (error) {
    console.error(error);
    showResult(result, "Could not save the registration. Please use WhatsApp to register directly.", "error");
  }
});

// ---------------- REVIEWS ----------------
async function renderReviews() {
  const grid = qs("#reviewGrid");
  const empty = qs("#emptyReviews");
  try {
    const reviews = await getPublicReviews();
    grid.innerHTML = reviews.map(r => `
      <article class="review-card">
        <div class="review-stars">${"★".repeat(Number(r.rating || 5))}${"☆".repeat(5 - Number(r.rating || 5))}</div>
        <p class="review-comment">“${safe(r.comment)}”</p>
        <div class="review-person">
          <div class="review-avatar">${safe((r.name || "J").slice(0,1).toUpperCase())}</div>
          <div><strong>${safe(r.name)}</strong><small>${safe(r.role || "Client")}</small></div>
        </div>
      </article>
    `).join("");
    empty.style.display = reviews.length ? "none" : "";
  } catch (error) {
    grid.innerHTML = "";
    empty.style.display = "";
  }
}

qs("#openReviewBtn")?.addEventListener("click", () => openModal("reviewModal"));
qs("#reviewForm")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const result = qs("#reviewResult");
  const form = e.currentTarget;
  const data = Object.fromEntries(new FormData(form).entries());
  showResult(result, "Submitting review…");
  try {
    await insertRecord("reviews", { ...data, rating: Number(data.rating), status: "pending" });
    showResult(result, "Thank you. Your review was submitted for approval.", "success");
    form.reset();
    notifySubmission("NEW REVIEW", data);
    toast("Review sent for approval.");
    setTimeout(() => closeModal("reviewModal"), 800);
  } catch (error) {
    showResult(result, "Review could not be submitted. Please try again.", "error");
  }
});
renderReviews();

// ---------------- CHAT BOT ----------------
const chatPanel = qs("#chatPanel");
const chatLauncher = qs("#chatLauncher");
const chatMessages = qs("#chatMessages");
const chatInput = qs("#chatInput");

function addChatBubble(text, type = "bot") {
  const div = document.createElement("div");
  div.className = `chat-bubble ${type}`;
  div.textContent = text;
  chatMessages.appendChild(div);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function aiReply(message) {
  const m = message.toLowerCase();

  if (m.includes("price") || m.includes("cost") || m.includes("how much")) {
    return "Plans start at KSh 500+ and go up to KSh 10,000. The main levels are 500+, 1,500, 3,000, 5,000, 7,500 and 10,000. Tap Pricing or Hire Me to choose.";
  }
  if (m.includes("hire") || m.includes("book") || m.includes("project")) {
    return "Use the Hire Me form, choose a service and budget, then submit your project brief. For a faster conversation, use the floating WhatsApp button.";
  }
  if (m.includes("class") || m.includes("learn") || m.includes("9") || m.includes("twiva") || m.includes("canva")) {
    return "The free online classes are scheduled daily at 9:00 PM via TikTok. Topics include freelancing, Canva, AI tools, digital marketing, online jobs and Twiva.";
  }
  if (m.includes("payment") || m.includes("mpesa") || m.includes("pay")) {
    return "The displayed M-PESA number is 0142617814. Select a plan, submit the request, and keep your transaction reference for verification. Automatic STK Push needs a secure Daraja backend.";
  }
  if (m.includes("whatsapp") || m.includes("call") || m.includes("contact")) {
    return "WhatsApp: 0142617814. Email: emmanuelouko21@gmail.com. You can also use the Call button for direct contact.";
  }
  if (m.includes("service") || m.includes("do you")) {
    return "Jay offers web development, graphic design, digital marketing, AI workflows, online-work setup, and Canva/Twiva training.";
  }
  if (m.includes("social") || m.includes("instagram") || m.includes("facebook") || m.includes("youtube") || m.includes("tiktok")) {
    return "All main social channels are in the Contact / Social section. The fastest route for project conversations is WhatsApp.";
  }
  return "I can help with prices, services, hiring, payments, classes or contact details. Try asking: “How much is a website?”";
}

function sendChat(message) {
  const clean = message.trim();
  if (!clean) return;
  addChatBubble(clean, "user");
  setTimeout(() => addChatBubble(aiReply(clean), "bot"), 350);
}

chatLauncher?.addEventListener("click", () => {
  const open = chatPanel.classList.toggle("open");
  chatPanel.setAttribute("aria-hidden", String(!open));
  if (open) setTimeout(() => chatInput?.focus(), 150);
});
qs("#chatClose")?.addEventListener("click", () => {
  chatPanel.classList.remove("open");
  chatPanel.setAttribute("aria-hidden", "true");
});
qs("#chatForm")?.addEventListener("submit", e => {
  e.preventDefault();
  sendChat(chatInput.value);
  chatInput.value = "";
});
qsa(".chat-suggestions button").forEach(btn => {
  btn.addEventListener("click", () => sendChat(btn.dataset.question));
});

// ---------------- ADMIN ----------------
let adminState = { registrations: [], leads: [], reviews: [] };

function adminEsc(value) {
  return safe(value);
}

function statusBadge(status) {
  return `<span class="status-badge status-${adminEsc(status)}">${adminEsc(status)}</span>`;
}

function adminCard(item, type) {
  const common = `
    <div class="admin-item">
      <div class="admin-item-head">
        <div><strong>${adminEsc(item.name)}</strong><small> ${type === "registration" ? adminEsc(item.program) : type === "lead" ? adminEsc(item.service) : adminEsc(item.role || "Client")}</small></div>
        ${statusBadge(item.status)}
      </div>
      <p>${adminEsc(item.email)} • ${adminEsc(item.phone || "")}</p>
      ${item.budget ? `<p><strong>Budget:</strong> ${adminEsc(item.budget)}</p>` : ""}
      ${item.plan ? `<p><strong>Plan:</strong> ${adminEsc(item.plan)}</p>` : ""}
      <p>${adminEsc(item.message || "No message")}</p>
      <small>${new Date(item.created_at).toLocaleString()}</small>
      <div class="admin-actions">
        <button class="btn btn-ghost" data-action="approved" data-table="${type === "registration" ? "registrations" : type === "lead" ? "leads" : "reviews"}" data-id="${adminEsc(item.id)}"><i class="fa-solid fa-check"></i> Approve</button>
        <button class="btn btn-ghost" data-action="rejected" data-table="${type === "registration" ? "registrations" : type === "lead" ? "leads" : "reviews"}" data-id="${adminEsc(item.id)}"><i class="fa-solid fa-xmark"></i> Reject</button>
        <a class="btn btn-ghost" href="https://wa.me/${CONFIG.WHATSAPP_NUMBER}?text=${encodeURIComponent(`Hi ${item.name}, this is Jay Ouko following up on your ${type === "registration" ? "registration" : type === "lead" ? "project request" : "review"}.`)}" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
      </div>
    </div>`;
  return common;
}

function renderAdmin() {
  qs("#adminRegCount").textContent = adminState.registrations.length;
  qs("#adminLeadCount").textContent = adminState.leads.length;
  qs("#adminReviewCount").textContent = adminState.reviews.filter(r => r.status === "pending").length;
  qs("#adminApprovedCount").textContent = [
    ...adminState.registrations, ...adminState.leads, ...adminState.reviews
  ].filter(x => x.status === "approved").length;

  const lists = [
    ["#adminRegistrations", adminState.registrations, "registration"],
    ["#adminLeads", adminState.leads, "lead"],
    ["#adminReviews", adminState.reviews, "review"]
  ];

  lists.forEach(([selector, rows, type]) => {
    const el = qs(selector);
    if (!rows.length) {
      el.innerHTML = `<div class="empty-admin">No records yet.</div>`;
    } else {
      el.innerHTML = rows.map(row => adminCard(row, type)).join("");
    }
  });

  qsa(".admin-actions [data-action]").forEach(btn => {
    btn.addEventListener("click", async () => {
      try {
        await updateAdminRecord(btn.dataset.table, btn.dataset.id, btn.dataset.action);
        toast(`Record ${btn.dataset.action}.`);
        await loadAdminData();
      } catch (error) {
        toast(error.message || "Could not update record.");
      }
    });
  });
}

async function loadAdminData() {
  try {
    const [registrations, leads, reviews] = await Promise.all([
      getAdminTable("registrations"),
      getAdminTable("leads"),
      getAdminTable("reviews")
    ]);
    adminState = { registrations, leads, reviews };
    renderAdmin();
  } catch (error) {
    console.error(error);
    toast(error.message || "Could not load admin records.");
  }
}

async function refreshAdminAuth() {
  if (!supabase) return;
  const { data } = await supabase.auth.getSession();
  const user = data?.session?.user;

  if (user && user.email?.toLowerCase() === CONFIG.ADMIN_EMAIL.toLowerCase()) {
    qs("#adminLoginView").hidden = true;
    qs("#adminDashboard").hidden = false;
    qs("#adminAuthStatus").textContent = `Signed in as ${user.email}`;
    await loadAdminData();
  } else {
    qs("#adminLoginView").hidden = false;
    qs("#adminDashboard").hidden = true;
  }
}

qs("#openAdminBtn")?.addEventListener("click", async () => {
  openModal("adminModal");
  if (!isSupabaseConfigured) {
    showResult(qs("#adminLoginResult"), "Add your Supabase URL + publishable key in app.js, then create your Auth admin user.", "error");
    qs("#adminDashboard").hidden = true;
    return;
  }
  await refreshAdminAuth();
});

qs("#adminLoginForm")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const result = qs("#adminLoginResult");
  if (!supabase) {
    showResult(result, "Supabase is not configured yet.", "error");
    return;
  }

  const data = Object.fromEntries(new FormData(e.currentTarget).entries());
  showResult(result, "Signing in securely…");

  const { error } = await supabase.auth.signInWithPassword({
    email: data.email,
    password: data.password
  });

  if (error) {
    showResult(result, error.message, "error");
    return;
  }
  showResult(result, "Signed in.", "success");
  await refreshAdminAuth();
});

qs("#adminSignOut")?.addEventListener("click", async () => {
  if (supabase) await supabase.auth.signOut();
  qs("#adminLoginView").hidden = false;
  qs("#adminDashboard").hidden = true;
  toast("Signed out.");
});

qsa(".admin-tab").forEach(tab => {
  tab.addEventListener("click", () => {
    qsa(".admin-tab").forEach(t => t.classList.remove("active"));
    qsa(".admin-section").forEach(s => s.classList.remove("active"));
    tab.classList.add("active");
    qs(`#tab-${tab.dataset.tab}`).classList.add("active");
  });
});

qs("#setupSql").textContent = SQL_SETUP;
qs("#copySql")?.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(SQL_SETUP);
    toast("Supabase SQL copied.");
  } catch {
    toast("Select and copy the SQL manually.");
  }
});

if (supabase) {
  supabase.auth.onAuthStateChange(() => setTimeout(refreshAdminAuth, 0));
}

// ---------------- FOOTER / PRIVACY ----------------
qs("#year").textContent = new Date().getFullYear();

// ---------------- CONFIG NOTICE ----------------
if (!isSupabaseConfigured) {
  console.info("Jay Ouko site is running in public form-preview mode. Configure Supabase in app.js for central registrations + secure admin access.");
}
